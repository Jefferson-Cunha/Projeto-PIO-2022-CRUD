﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetoContasemDia_0._0._1
{
    class Dados
    {

        public bool inserirUsuario(String Nome, String Email, String Celular, String Senha)
        {
            return true;
        }
    }
}
