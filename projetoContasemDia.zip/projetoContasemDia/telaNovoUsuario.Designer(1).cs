﻿namespace projetoContasemDia_0._0._1
{
    partial class telaNovoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(telaNovoUsuario));
            this.txtSenhaConf = new System.Windows.Forms.TextBox();
            this.txtSenhaUsuario = new System.Windows.Forms.TextBox();
            this.txtCelularUsuario = new System.Windows.Forms.TextBox();
            this.txtEmailUsuario = new System.Windows.Forms.TextBox();
            this.txtNovoUsuario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAcessar = new System.Windows.Forms.Button();
            this.txtErrCriarCadastro = new System.Windows.Forms.Label();
            this.txtSenhaNaoConfere = new System.Windows.Forms.Label();
            this.txtCampoVazio = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // txtSenhaConf
            // 
            this.txtSenhaConf.Location = new System.Drawing.Point(325, 497);
            this.txtSenhaConf.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtSenhaConf.Name = "txtSenhaConf";
            this.txtSenhaConf.PasswordChar = '*';
            this.txtSenhaConf.Size = new System.Drawing.Size(158, 20);
            this.txtSenhaConf.TabIndex = 42;
            this.txtSenhaConf.UseSystemPasswordChar = true;
            // 
            // txtSenhaUsuario
            // 
            this.txtSenhaUsuario.Location = new System.Drawing.Point(325, 459);
            this.txtSenhaUsuario.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtSenhaUsuario.Name = "txtSenhaUsuario";
            this.txtSenhaUsuario.PasswordChar = '*';
            this.txtSenhaUsuario.Size = new System.Drawing.Size(158, 20);
            this.txtSenhaUsuario.TabIndex = 41;
            this.txtSenhaUsuario.UseSystemPasswordChar = true;
            // 
            // txtCelularUsuario
            // 
            this.txtCelularUsuario.Location = new System.Drawing.Point(325, 422);
            this.txtCelularUsuario.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtCelularUsuario.Name = "txtCelularUsuario";
            this.txtCelularUsuario.Size = new System.Drawing.Size(158, 20);
            this.txtCelularUsuario.TabIndex = 40;
            // 
            // txtEmailUsuario
            // 
            this.txtEmailUsuario.Location = new System.Drawing.Point(325, 385);
            this.txtEmailUsuario.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtEmailUsuario.Name = "txtEmailUsuario";
            this.txtEmailUsuario.Size = new System.Drawing.Size(158, 20);
            this.txtEmailUsuario.TabIndex = 39;
            // 
            // txtNovoUsuario
            // 
            this.txtNovoUsuario.Location = new System.Drawing.Point(325, 353);
            this.txtNovoUsuario.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtNovoUsuario.Name = "txtNovoUsuario";
            this.txtNovoUsuario.Size = new System.Drawing.Size(158, 20);
            this.txtNovoUsuario.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(138, 308);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(345, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "Informe os dados abaixo para criar uma conta!\r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(123, 495);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Confirmar Senha: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(123, 457);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "Senha: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(123, 422);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "Celular: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(123, 385);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 20);
            this.label2.TabIndex = 33;
            this.label2.Text = "E-mail: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(123, 353);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 20);
            this.label1.TabIndex = 32;
            this.label1.Text = "Nome: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Italic);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(113, 578);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(272, 21);
            this.label7.TabIndex = 43;
            this.label7.Text = "Bonde do TI Sem Freio © 2022  by ";
            // 
            // btnAcessar
            // 
            this.btnAcessar.AutoSize = true;
            this.btnAcessar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcessar.Location = new System.Drawing.Point(216, 549);
            this.btnAcessar.Name = "btnAcessar";
            this.btnAcessar.Size = new System.Drawing.Size(169, 26);
            this.btnAcessar.TabIndex = 45;
            this.btnAcessar.Text = "Criar Conta";
            this.btnAcessar.UseVisualStyleBackColor = true;
            this.btnAcessar.Click += new System.EventHandler(this.btnAcessar_Click);
            // 
            // txtErrCriarCadastro
            // 
            this.txtErrCriarCadastro.AutoSize = true;
            this.txtErrCriarCadastro.BackColor = System.Drawing.Color.Transparent;
            this.txtErrCriarCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.txtErrCriarCadastro.ForeColor = System.Drawing.Color.Red;
            this.txtErrCriarCadastro.Location = new System.Drawing.Point(229, 521);
            this.txtErrCriarCadastro.Name = "txtErrCriarCadastro";
            this.txtErrCriarCadastro.Size = new System.Drawing.Size(0, 15);
            this.txtErrCriarCadastro.TabIndex = 49;
            // 
            // txtSenhaNaoConfere
            // 
            this.txtSenhaNaoConfere.AutoSize = true;
            this.txtSenhaNaoConfere.BackColor = System.Drawing.Color.Transparent;
            this.txtSenhaNaoConfere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.txtSenhaNaoConfere.ForeColor = System.Drawing.Color.Red;
            this.txtSenhaNaoConfere.Location = new System.Drawing.Point(213, 524);
            this.txtSenhaNaoConfere.Name = "txtSenhaNaoConfere";
            this.txtSenhaNaoConfere.Size = new System.Drawing.Size(0, 15);
            this.txtSenhaNaoConfere.TabIndex = 47;
            // 
            // txtCampoVazio
            // 
            this.txtCampoVazio.AutoSize = true;
            this.txtCampoVazio.BackColor = System.Drawing.Color.Transparent;
            this.txtCampoVazio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCampoVazio.ForeColor = System.Drawing.Color.Red;
            this.txtCampoVazio.Location = new System.Drawing.Point(199, 521);
            this.txtCampoVazio.Name = "txtCampoVazio";
            this.txtCampoVazio.Size = new System.Drawing.Size(0, 15);
            this.txtCampoVazio.TabIndex = 46;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Italic);
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.linkLabel1.Location = new System.Drawing.Point(378, 578);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(118, 21);
            this.linkLabel1.TabIndex = 50;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Contas em Dia";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // telaNovoUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(612, 608);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.txtErrCriarCadastro);
            this.Controls.Add(this.txtSenhaNaoConfere);
            this.Controls.Add(this.txtCampoVazio);
            this.Controls.Add(this.btnAcessar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtSenhaConf);
            this.Controls.Add(this.txtSenhaUsuario);
            this.Controls.Add(this.txtCelularUsuario);
            this.Controls.Add(this.txtEmailUsuario);
            this.Controls.Add(this.txtNovoUsuario);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "telaNovoUsuario";
            this.Text = "Novo Usuário";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSenhaConf;
        private System.Windows.Forms.TextBox txtSenhaUsuario;
        private System.Windows.Forms.TextBox txtCelularUsuario;
        private System.Windows.Forms.TextBox txtEmailUsuario;
        private System.Windows.Forms.TextBox txtNovoUsuario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAcessar;
        private System.Windows.Forms.Label txtErrCriarCadastro;
        private System.Windows.Forms.Label txtSenhaNaoConfere;
        private System.Windows.Forms.Label txtCampoVazio;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}