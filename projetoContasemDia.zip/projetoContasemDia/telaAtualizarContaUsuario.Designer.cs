﻿namespace projetoContasemDia_0._0._1
{
    partial class telaAtualizarContaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(telaAtualizarContaUsuario));
            this.lnkFooter = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtPrestador = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtVlConta = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTpConta = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCampoVazio = new System.Windows.Forms.Label();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.DtVenci = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lnkFooter
            // 
            this.lnkFooter.AutoSize = true;
            this.lnkFooter.BackColor = System.Drawing.Color.Transparent;
            this.lnkFooter.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Italic);
            this.lnkFooter.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lnkFooter.Location = new System.Drawing.Point(287, 485);
            this.lnkFooter.Name = "lnkFooter";
            this.lnkFooter.Size = new System.Drawing.Size(118, 21);
            this.lnkFooter.TabIndex = 40;
            this.lnkFooter.TabStop = true;
            this.lnkFooter.Text = "Contas em Dia";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Italic);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(22, 485);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(272, 21);
            this.label2.TabIndex = 39;
            this.label2.Text = "Bonde do TI Sem Freio © 2022  by ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(76, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(288, 92);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // txtPrestador
            // 
            this.txtPrestador.AcceptsReturn = true;
            this.txtPrestador.AcceptsTab = true;
            this.txtPrestador.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrestador.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrestador.Location = new System.Drawing.Point(201, 179);
            this.txtPrestador.Name = "txtPrestador";
            this.txtPrestador.Size = new System.Drawing.Size(163, 22);
            this.txtPrestador.TabIndex = 50;
            this.txtPrestador.Tag = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Italic);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label6.Location = new System.Drawing.Point(66, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 19);
            this.label6.TabIndex = 49;
            this.label6.Text = "Cod Próprio:";
            // 
            // txtVlConta
            // 
            this.txtVlConta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtVlConta.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlConta.HideSelection = false;
            this.txtVlConta.Location = new System.Drawing.Point(204, 268);
            this.txtVlConta.Name = "txtVlConta";
            this.txtVlConta.Size = new System.Drawing.Size(163, 22);
            this.txtVlConta.TabIndex = 54;
            this.txtVlConta.Text = "R$";
            this.txtVlConta.WordWrap = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Italic);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label4.Location = new System.Drawing.Point(70, 269);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 19);
            this.label4.TabIndex = 53;
            this.label4.Text = "Valor da conta:";
            // 
            // txtTpConta
            // 
            this.txtTpConta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTpConta.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTpConta.Location = new System.Drawing.Point(204, 226);
            this.txtTpConta.Name = "txtTpConta";
            this.txtTpConta.Size = new System.Drawing.Size(163, 22);
            this.txtTpConta.TabIndex = 52;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Italic);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label3.Location = new System.Drawing.Point(69, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 19);
            this.label3.TabIndex = 51;
            this.label3.Text = "Titulo:";
            // 
            // txtCampoVazio
            // 
            this.txtCampoVazio.AutoSize = true;
            this.txtCampoVazio.BackColor = System.Drawing.Color.Transparent;
            this.txtCampoVazio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCampoVazio.ForeColor = System.Drawing.Color.Red;
            this.txtCampoVazio.Location = new System.Drawing.Point(119, 357);
            this.txtCampoVazio.Name = "txtCampoVazio";
            this.txtCampoVazio.Size = new System.Drawing.Size(0, 15);
            this.txtCampoVazio.TabIndex = 58;
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(139, 384);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(155, 31);
            this.btnSalvar.TabIndex = 57;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // DtVenci
            // 
            this.DtVenci.CalendarFont = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtVenci.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.DtVenci.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.DtVenci.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtVenci.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DtVenci.Location = new System.Drawing.Point(202, 321);
            this.DtVenci.Name = "DtVenci";
            this.DtVenci.Size = new System.Drawing.Size(163, 23);
            this.DtVenci.TabIndex = 56;
            this.DtVenci.UseWaitCursor = true;
            this.DtVenci.Value = new System.DateTime(2022, 5, 12, 15, 4, 23, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Italic);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label5.Location = new System.Drawing.Point(67, 321);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 19);
            this.label5.TabIndex = 55;
            this.label5.Text = "Data de Venc:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Italic);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(57, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(326, 19);
            this.label1.TabIndex = 59;
            this.label1.Text = "Preencha os dados abaixo para atualizar a conta!";
            // 
            // telaAtualizarContaUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(437, 515);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCampoVazio);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.DtVenci);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtVlConta);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTpConta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPrestador);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lnkFooter);
            this.Controls.Add(this.label2);
            this.Name = "telaAtualizarContaUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Atualizar Conta ";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lnkFooter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtPrestador;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtVlConta;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTpConta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label txtCampoVazio;
        private System.Windows.Forms.Button btnSalvar;
        public System.Windows.Forms.DateTimePicker DtVenci;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
    }
}