﻿namespace projetoContasemDia_0._0._1
{
    partial class telaCriarNovaSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(telaCriarNovaSenha));
            this.txtCamposVazios = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSenha02 = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCampoVazio = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.txtSenhaNaoConf = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCamposVazios
            // 
            this.txtCamposVazios.AutoSize = true;
            this.txtCamposVazios.BackColor = System.Drawing.Color.Transparent;
            this.txtCamposVazios.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.txtCamposVazios.ForeColor = System.Drawing.Color.Red;
            this.txtCamposVazios.Location = new System.Drawing.Point(187, 473);
            this.txtCamposVazios.Name = "txtCamposVazios";
            this.txtCamposVazios.Size = new System.Drawing.Size(0, 15);
            this.txtCamposVazios.TabIndex = 55;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Italic);
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.linkLabel1.Location = new System.Drawing.Point(377, 581);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(118, 21);
            this.linkLabel1.TabIndex = 54;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Contas em Dia";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Italic);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(110, 581);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(272, 21);
            this.label3.TabIndex = 53;
            this.label3.Text = "Bonde do TI Sem Freio © 2022  by ";
            // 
            // txtSenha02
            // 
            this.txtSenha02.Location = new System.Drawing.Point(268, 428);
            this.txtSenha02.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtSenha02.Name = "txtSenha02";
            this.txtSenha02.Size = new System.Drawing.Size(202, 20);
            this.txtSenha02.TabIndex = 51;
            this.txtSenha02.UseSystemPasswordChar = true;
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(268, 382);
            this.txtSenha.Margin = new System.Windows.Forms.Padding(3, 3, 3, 6);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(202, 20);
            this.txtSenha.TabIndex = 50;
            this.txtSenha.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(140, 426);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 49;
            this.label1.Text = "Conf Senha:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(140, 382);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 48;
            this.label2.Text = "Senha:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Italic);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(226, 330);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 20);
            this.label6.TabIndex = 47;
            this.label6.Text = "Crie sua nova senha!";
            // 
            // txtCampoVazio
            // 
            this.txtCampoVazio.AutoSize = true;
            this.txtCampoVazio.BackColor = System.Drawing.Color.Transparent;
            this.txtCampoVazio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.txtCampoVazio.ForeColor = System.Drawing.Color.Red;
            this.txtCampoVazio.Location = new System.Drawing.Point(197, 473);
            this.txtCampoVazio.Name = "txtCampoVazio";
            this.txtCampoVazio.Size = new System.Drawing.Size(0, 15);
            this.txtCampoVazio.TabIndex = 58;
            // 
            // btnEnviar
            // 
            this.btnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnEnviar.Location = new System.Drawing.Point(241, 500);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(110, 28);
            this.btnEnviar.TabIndex = 59;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // txtSenhaNaoConf
            // 
            this.txtSenhaNaoConf.AutoSize = true;
            this.txtSenhaNaoConf.BackColor = System.Drawing.Color.Transparent;
            this.txtSenhaNaoConf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.txtSenhaNaoConf.ForeColor = System.Drawing.Color.Red;
            this.txtSenhaNaoConf.Location = new System.Drawing.Point(215, 463);
            this.txtSenhaNaoConf.Name = "txtSenhaNaoConf";
            this.txtSenhaNaoConf.Size = new System.Drawing.Size(0, 15);
            this.txtSenhaNaoConf.TabIndex = 60;
            // 
            // telaCriarNovaSenha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(612, 608);
            this.Controls.Add(this.txtSenhaNaoConf);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.txtCampoVazio);
            this.Controls.Add(this.txtCamposVazios);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSenha02);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Name = "telaCriarNovaSenha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Criar Nova Senha";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label txtCamposVazios;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSenha02;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label txtCampoVazio;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Label txtSenhaNaoConf;
    }
}